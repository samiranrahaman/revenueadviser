<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        
        <div class="pull-left info">
          <?php echo $user_info->user_first_name.' '.$user_info->user_last_name;
		  //print_r($user_info);
		  ?>
          <!-- <a href="#"><i class="fa fa-circle text-success"></i> Online</a> -->
        </div>
        <br/>
        <br/>
      </div>
      <!-- search form -->
      <!-- <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form> -->
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
     
			 <li class="active treeview">

  			  <a href="#">
  				<i class="fa fa-dashboard"></i> <span>Revenue Advizer</span> <i class="fa fa-angle-left pull-right"></i>
  			  </a>
  			  <ul class="treeview-menu">
            <li><a href="<?php echo base_url();?>index.php/Dashboard"><i class="fa fa-dashboard "></i>Dashboard</a></li>
			<li><a href="<?php echo base_url();?>index.php/Dashboard"><i class="fa fa-dashboard "></i>My Reports</a></li>
			<li><a href="<?php echo base_url();?>index.php/Dashboard"><i class="fa  fa-cog"></i>Simulator</a></li>
			<li><a href="<?php echo base_url();?>index.php/Dashboard"><i class="fa fa-book "></i>Daily Data</a></li>
			<li><a href="<?php echo base_url();?>index.php/Dashboard"><i class="fa  fa-th "></i>Fixed charges</a></li>
	        <li><a href="<?php echo base_url();?>index.php/Intregation"><i class="fa  fa-cog"></i>Intregation</a></li>
			</ul>  
    </section>
    <!-- /.sidebar -->
  </aside>
