<?php
/*
    Description : Model for Intregation
    Author      : Deepak kv
    Date        : 28/10/2016
*/
class Intregation extends CI_Model
{
	public function __construct()
    {
        parent::__construct();
    }
    public function post_storeinfo($account_name,$apikey,$password,$url)
    {
        //$sql="insert into `rev_storinfo` set store_name='$account_name',store_apikey='$apikey',store_app_password='$password',store_url='$url',user_id=1";
		//$query_insert = $this->db->query($sql);
		
		/* $data = array(
        'store_name' => $account_name,
        'store_apikey' => $apikey,
        'store_app_password' =>$password,
		'store_url' => $url,
		);

		$this->db->insert('rev_storinfo', $data);
		//return $this->db->get_compiled_insert()	;
		return $id=$this->db->insert_id() ; */
		return 1;
    }
    
}

