<?php
/*
  Description : Controller for Intregation
  Author      : samiran rahaman
  Date        : 16/02/2017
*/
class Intregation extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		 $this->load->library('session');
		//$this->load->model('Intregation_model');

		if(!$this->session->userdata('user_info'))
		{
		   redirect('Login');
		} 			
	}
	public function index()
    {   
      $data['user_info'] =$this->session->userdata('user_info');
      $this->load->view('common_header');
      $this->load->view('common_sidemenu',$data);
     // $this->load->view('Itregation/Main');
	 $this->load->view('Intregation/Main',$data);
      $this->load->view('common_footer');        	
    }
	public function store_fulfillment()
    {
		/* $postdata = file_get_contents("php://input");
		     $request = json_decode($postdata);
		     $account_name = $request->account_name;
		     $apikey = $request->apikey;
			 $password = $request->password;
		     $url = $request->url; */
			 
			 // $success=$this->Intregation_model->post_store_info($account_name,$apikey,$password,$url);	
			  $success=$this->Intregation_model->post_storeinfo('ddd','ddd','ffff','gggg');	
			// $success=$this->Login_model->verify_login_credintial('admin','admin');	
			 //print_r($success);	
			 /* if(isset($success)) 
			 {
			 	
			 	$this->session->set_userdata('user_info',$success[0]);
			 	//echo true;
			    $return_value=array('status'=>"1");
				echo json_encode($return_value);
			 }
			 else
			 {
				// echo false;
				$return_value=array('status'=>"0");
				echo json_encode($return_value);
			 } */
			 $return_value=array('status'=>"0");
				echo json_encode($return_value);
	}
    
 }